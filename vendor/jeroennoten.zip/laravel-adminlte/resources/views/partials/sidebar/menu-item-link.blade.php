<li @isset($item['id']) id="{{ $item['id'] }}" @endisset class="nav-item">

    <a style="display: flex; justify-content: flex-start; align-items: center; align-content: center; gap: 1rem" class="nav-link {{ $item['class'] }} @isset($item['shift']) {{ $item['shift'] }} @endisset"
       href="{{ $item['href'] }}" @isset($item['target']) target="{{ $item['target'] }}" @endisset
       {!! $item['data-compiled'] ?? '' !!}>

        <ion-icon style="font-size: 25px" name="{{ $item['icon'] ?? 'far fa-fw fa-circle' }}{{
            isset($item['icon_color']) ? 'text-'.$item['icon_color'] : ''
        }}"></ion-icon>

        <p>
            {{ $item['text'] }}

            @isset($item['label'])
                <span class="badge badge-{{ $item['label_color'] ?? 'primary' }} right">
                    {{ $item['label'] }}
                </span>
            @endisset
        </p>

    </a>

</li>
